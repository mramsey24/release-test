import {globby} from 'globby';

const paths = await globby(['my-artifact' ]);

console.log(paths);
